<?php

namespace Pterodactyl\Exceptions;

use Exception;

class PterodactylException extends Exception
{
}
