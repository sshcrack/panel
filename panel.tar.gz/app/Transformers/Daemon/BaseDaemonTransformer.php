<?php

namespace Pterodactyl\Transformers\Daemon;

use League\Fractal\TransformerAbstract;

abstract class BaseDaemonTransformer extends TransformerAbstract
{
}
